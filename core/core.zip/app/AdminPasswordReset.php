<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AdminPasswordReset extends Model
{
    protected $guarded = ['id'];
}
