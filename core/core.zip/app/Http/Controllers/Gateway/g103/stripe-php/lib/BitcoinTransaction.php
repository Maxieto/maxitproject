<?php

namespace Stripe;

/**
 * Class BitcoinTransaction
 *
 * @package Stripe
 */
class BitcoinTransaction extends ApiResource
{

}
